# App Limits

## Per-app limits authoring (implemented in parent authoring)
- Configure per-app time limits.
- Validation prevents invalid configurations.

## Enforcement (partial)
Kid enforcement wiring may be platform-dependent; tracked in the Feature Registry.
