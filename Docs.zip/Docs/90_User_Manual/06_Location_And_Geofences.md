# Location and Geofences

## Geofence overlay UX (implemented)
- Geofence authoring/review surfaces exist in the Parent UI (Location area).
- Overlay UX has been iterated for readability and compact layout.

## Kid evaluation + alerts (implemented)
- Kid agent evaluation produces inside/outside transitions.
- Transitions generate activity-driven alerts.
