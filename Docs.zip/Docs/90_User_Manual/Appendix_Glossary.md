# Glossary

- **SSOT**: Single Source of Truth — the Local Control Plane is authoritative.
- **Local Control Plane**: local-first API/storage layer used by Parent and Kid components.
- **Marker tests**: small tests that guard critical behaviors and regressions.
- **ACK**: acknowledging an alert in the inbox.
