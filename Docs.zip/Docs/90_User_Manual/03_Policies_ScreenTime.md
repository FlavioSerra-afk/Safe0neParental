# Screen Time Policies

## Grace periods + warnings (implemented in parent authoring)
You can configure:
- Grace minutes
- Warning thresholds (e.g., 5 min / 1 min)

## Enforcement (partial)
The authoring surface exists; enforcement on the Kid side is tracked separately until fully end-to-end on all platforms.
