# Acceptance Criteria — Child App

Use patch acceptance tests in Milestones_Patches_DETAILED.md.
