# Security & Privacy — Safe0ne Parental (Shared)

Updated: 2026-02-02

## Principles
- Privacy-first telemetry (aggregates by default).
- Explainable restrictions (child always sees “why”).
- Secure storage and secure IPC.
- Best-effort anti-tamper with parent alerts.
