# Glossary — Safe0ne Parental (Shared)

- Parent App: adult controller UI
- Child App/Agent: enforcement + child UX
- Control Plane: stores policies/versions/requests/decisions
- Mode: Lockdown/Open/Homework/Bedtime
- Always Allowed: exceptions that always work
- Request: child asks for access/time
- Grant: time-boxed exception approved by parent
- Alert: event requiring parent attention
