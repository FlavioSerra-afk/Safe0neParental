# Data Model — Safe0ne Parental (Shared)

Updated: 2026-02-02

## Policy precedence
Always Allowed > Grants > Mode > Schedules/Budgets

(Refine entity fields as implementation begins; keep this file as the shared semantic truth.)
