# Safe0ne Parental — UI/UX Spec Pack

This ZIP contains the authoritative UI/UX spec for the Parent App dashboard UI.

Files:
- Safe0ne_Parental_UI_UX_Spec.md
